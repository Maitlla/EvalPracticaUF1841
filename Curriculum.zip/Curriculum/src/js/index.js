
function app() {
    const numbers = [22, 1, 4, 3, 5, 7, 8, 9, 12, 11];
    const odd = []; //impar  si el módulo es 1
    const even = [] //par    si el módulo es 0

    for (let item of numbers) {

        console.log("item:", item);

        if(item % 2 === 0){
        
            alert("El número "+numbers+" es par");
        
        }else{
            
            alert("El número "+numbers+" es impar");
            
        }

        console.log("odd:", odd);
        console.log("even:", even);
    }




/*
console.log("Inicio");

console.log("Operación de módulo:");
console.log("13%10:", 13%10);

console.log("Par/impar");
console.log("33:", 33%2);
console.log("32:", 32%2);

console.log("Añadir elementos a array");
const number = 33;
const numbers = [];
numbers.push(number);
numbers.push(41);
console.log("numbers:", numbers);

console.log("Operadores condicionales:");
console.log("33 > 34:", 33 > 34);
console.log("33 < 34:", 33 < 34);
console.log("33 > 33:", 33 > 33);
console.log("33 >= 33:", 33 >= 33);
console.log("33 === 33:", 33 === 33);
console.log("'33' === 33:", "33" === 33);

console.log("Bifurcación lógica");
const n1 = 44;
const n2 = 55;
if (n1 >= n2) {
    console.log("n1-n2:", n1-n2)
}
if (n1 < n2) {
    console.log("n2-n1:", n2-n1)
}

if (n1 >= n2) {
    console.log("n1-n2:", n1-n2)
} else {
    console.log("n2-n1:", n2-n1)
}

*/

