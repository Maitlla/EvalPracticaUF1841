export const data = [  2,  10, 20, 35 ];

