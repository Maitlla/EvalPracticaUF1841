// Ejercicio 4
// index.js debería de imprimir la suma de todos los números en el array numbers pero no funciona, solucionalo

const numbers = [0,1,2];
let sum = 0;

for (let item of numbers) {
    sum += item;
}

console.log(sum) 

