# What the hell is a number?

Completa el código de [index.js](index.js) para separar los números y los strings contenidos en el array ```mix```.

El código proporcionado contiene un error que afecta a dos lineas consecutivas.Solucionalo.

## typeof

```javascript
typeof "a" // -> 'string'
typeof 9 // -> 'number'
```
En condicionales:
```javascript
if (typeof thisVariable === "string") {
    console.log("This variable is a string")
}
```