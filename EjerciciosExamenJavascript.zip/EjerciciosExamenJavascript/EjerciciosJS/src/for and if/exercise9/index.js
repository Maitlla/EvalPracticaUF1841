// Ejercicio 9
// Imprimir en la pantalla las tablas de multiplicar

let numbers = [0,1,2,3,4,5,6,7,8,9]

for ( let left of numbers) {
    for (let right of numbers) {
        console.log(left * right); // Devuelve el resultado de la multiplicación directamente
                                   // no imprime la multiplicación como en el ejercicio anterior
                                   
    }
}


