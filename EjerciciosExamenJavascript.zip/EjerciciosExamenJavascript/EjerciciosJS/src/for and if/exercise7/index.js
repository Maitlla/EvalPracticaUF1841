// Ejercicio 7
// Que imprima en la pantalla los elementos del 3 al 5 del array names

const names = ["Frodo", "Gandalf", "Turin", "Sauron", "Saruman", "Bilbo"];
                            
for (let i = 2; i < 5; i++) { // for clásico
    console.log(names[i]);
}

// console.log(names.slice(2,5));


